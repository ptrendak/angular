import {Component} from 'angular2/core';
@Component({
	selector: 'articles',
	template: '<div>To jest komponent</div>'
})
export class AppComponent{

}